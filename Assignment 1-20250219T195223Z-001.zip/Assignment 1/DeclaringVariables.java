
public class DeclaringVariables 
{

	public static void main(String[] args) 
	{
		// Text
		String str = "Hello";
		System.out.println(str);
		char ch='L';
		System.out.println(ch);
		// Numbers
		int hours = 20 ;
		System.out.println(hours);
		double days = 2.2; 
		System.out.println(days);
		// Boolean
		boolean bl = true;
		System.out.println(bl);
	
	}

}
