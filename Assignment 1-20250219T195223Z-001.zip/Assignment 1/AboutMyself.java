
public class AboutMyself 
{

	public static void main(String[] args) 
	{
		// Part 1 of question 2
		System.out.println("My name is Mia Delpriora");
		System.out.println("I was born in China");
		System.out.println("I like drawing , painting and listening to music");
		
		// Part 2 of question 2
		System.out.println("My name is Mia Delpriora\nI was born in China\nI like drawing , painting and listening to music");
		
	}

}
